package com.iitj.ecgserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcgserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
