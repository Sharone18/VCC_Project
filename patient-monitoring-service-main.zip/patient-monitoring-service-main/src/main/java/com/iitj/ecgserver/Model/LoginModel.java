package com.iitj.ecgserver.Model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginModel {
    private String userId;
    private String password;
}
